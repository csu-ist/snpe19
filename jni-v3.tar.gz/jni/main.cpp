//==============================================================================
//
//  Copyright (c) 2015-2018 Qualcomm Technologies, Inc.
//  All Rights Reserved.
//  Confidential and Proprietary - Qualcomm Technologies, Inc.
//
//==============================================================================
//
// This file contains an example application that loads and executes a neural
// network using the SNPE C++ API and saves the layer output to a file.
// Inputs to and outputs from the network are conveyed in binary form as single
// precision floating point values.
//

#include <iostream>
#include <getopt.h>
#include <fstream>
#include <cstdlib>
#include <vector>
#include <string>
#include <iterator>
#include <unordered_map>
#include <math.h>

#include "CheckRuntime.hpp"
#include "LoadContainer.hpp"
#include "SetBuilderOptions.hpp"
#include "LoadInputTensor.hpp"
#include "Util.hpp"
#include "udlExample.hpp"
#include "CreateUserBuffer.hpp"
#include "PreprocessInput.hpp"
#include "SaveOutputTensor.hpp"
#ifdef ANDROID
#include <GLES2/gl2.h>
#include "CreateGLBuffer.hpp"
#endif

#include "DlSystem/UserBufferMap.hpp"
#include "DlSystem/UDLFunc.hpp"
#include "DlSystem/IUserBuffer.hpp"
#include "DlContainer/IDlContainer.hpp"
#include "SNPE/SNPE.hpp"
#include "DiagLog/IDiagLog.hpp"

int main(int argc, char** argv)
{
    enum {UNKNOWN, USERBUFFER, ITENSOR};
    enum {CPUBUFFER, GLBUFFER};

    // Command line arguments
    static std::string dlc = "";
    static std::string OutputDir = "/opt/SNPE/snpe-1.19.2/models/srn/out-data/";
    const char* inputFile = "";
    const char* inputRAWFilePath = "/opt/SNPE/snpe-1.19.2/models/srn/data/cropped_700x700/plastic_cup_700x700.raw";
    size_t width=700;
    size_t height=700;
    size_t margin_reserve = 16;
    size_t margin_reserve_char = margin_reserve*4;
    std::string bufferTypeStr = "USERBUFFER";
    std::string userBufferSourceStr = "CPUBUFFER";

    // Process command line arguments
    int opt = 0;
    while ((opt = getopt(argc, argv, "hi:d:o:b:")) != -1)
    {
        switch (opt)
        {
            case 'h':
                std::cout
                    << "\nDESCRIPTION:\n"
                    << "------------\n"
                    << "Example application demonstrating how to load and execute a neural network\n"
                    << "using the SNPE C++ API.\n"
                    << "\n\n"
                    << "REQUIRED ARGUMENTS:\n"
                    << "-------------------\n"
                    << "  -d  <FILE>   Path to the DL container containing the network.\n"
                    << "  -i  <FILE>   Path to a file listing the inputs for the network.\n"
                    << "  -o  <PATH>   Path to directory to store output results.\n"
                    << "\n"
                    << "OPTIONAL ARGUMENTS:\n"
                    << "-------------------\n"
                    << "  -b  <TYPE>   Type of buffers to use [USERBUFFER, ITENSOR] (" << bufferTypeStr << "is default).\n";

                std::exit(0);
            case 'i':
                inputFile = optarg;
                break;
            case 'd':
                dlc = optarg;
                break;
            case 'o':
                OutputDir = optarg;
                break;
            case 'b':
                bufferTypeStr = optarg;
                break;
            default:
                std::cout << "Invalid parameter specified. Please run snpe-sample with the -h flag to see required arguments" << std::endl;
                std::exit(0);
        }
    }

   
    // Check if given arguments represent valid files
    std::ifstream dlcFile(dlc);
    std::ifstream inputList(inputFile);
    if (!dlcFile || !inputList) {
        std::cout << "Input list or dlc file not valid. Please ensure that you have provided a valid input list and dlc for processing. Run snpe-sample with the -h flag for more details" << std::endl;
        std::exit(0);
    }

    // Check if given buffer type is valid
    int bufferType;
    if (bufferTypeStr == "USERBUFFER") {
        bufferType = USERBUFFER;
    } else if (bufferTypeStr == "ITENSOR") {
        bufferType = ITENSOR;
    } else {
        std::cout << "Buffer type is not valid. Please run snpe-sample with the -h flag for more details" << std::endl;
        std::exit(0);
    }
    //Check if given user buffer source type is valid
    int userBufferSourceType;
    if (userBufferSourceStr == "CPUBUFFER")
    {
        userBufferSourceType = CPUBUFFER;
    } else if (userBufferSourceStr == "GLBUFFER") {
#ifndef ANDROID
        std::cout << "GLBUFFER mode is only supported on Android OS" << std::endl;
        std::exit(0);
#endif
        userBufferSourceType = GLBUFFER;
    } else {
        std::cout << "Source of user buffer type is not valid. Please run snpe-sample with the -h flag for more details" << std::endl;
        std::exit(0);
    }

    // Open the DL container that contains the network to execute.
    // Create an instance of the SNPE network from the now opened container.
    // The factory functions provided by SNPE allow for the specification
    // of which layers of the network should be returned as output and also
    // if the network should be run on the CPU or GPU.
    // The runtime availability API allows for runtime support to be queried.
    // If a selected runtime is not available, we will issue a warning and continue,
    // expecting the invalid configuration to be caught at SNPE network creation.
    zdl::DlSystem::UDLFactoryFunc udlFunc = sample::MyUDLFactory;
    zdl::DlSystem::UDLBundle udlBundle; udlBundle.cookie = (void*)0xdeadbeaf, udlBundle.func = udlFunc; // 0xdeadbeaf to test cookie

    static zdl::DlSystem::Runtime_t runtime = checkRuntime();
    std::unique_ptr<zdl::DlContainer::IDlContainer> container = loadContainerFromFile(dlc);
    bool useUserSuppliedBuffers = (bufferType == USERBUFFER);

    std::unique_ptr<zdl::SNPE::SNPE> snpe;
    zdl::DlSystem::PlatformConfig platformConfig;
#ifdef ANDROID
    CreateGLBuffer* glBuffer = new CreateGLBuffer();
    if (userBufferSourceType == GLBUFFER)
    {
      glBuffer->SetGPUPlatformConfig(platformConfig);
    }
#endif
    std::cerr << "setBuilderOptions: " << std::endl;
    snpe = setBuilderOptions(container, runtime, udlBundle, useUserSuppliedBuffers, platformConfig);
    std::cerr << "setBuilderOptions end. " << std::endl;
    std::cerr << "----------------------------. " << std::endl;
    // Configure logging output and start logging. The snpe-diagview
    // executable can be used to read the content of this diagnostics file
    const auto& inputNamesOpt = snpe->getInputTensorNames();
   
    std::cerr << "-----------_0" << std::endl;
    auto logger_opt = snpe->getDiagLogInterface();
    std::cerr << "----------------------------. " << std::endl;
    if (!logger_opt) throw std::runtime_error("SNPE failed to obtain logging interface");
    auto logger = *logger_opt;
    auto opts = logger->getOptions();
    std::cerr << "----------------------------. " << std::endl;
    opts.LogFileDirectory = OutputDir;
    if(!logger->setOptions(opts)) {
        std::cerr << "Failed to set options" << std::endl;
        std::exit(1);
    }
    if (!logger->start()) {
        std::cerr << "Failed to start logger" << std::endl;
        std::exit(1);
    }
    
    // Check the batch size for the container
    // SNPE 1.16.0 (and newer) assumes the first dimension of the tensor shape
    // is the batch size.
    zdl::DlSystem::TensorShape tensorShape;
    tensorShape = snpe->getInputDimensions();
    size_t batchSize = tensorShape.getDimensions()[0];
    std::cerr << "0000000000000000000000000000. " << std::endl;
#ifdef ANDROID
    if (userBufferSourceType == GLBUFFER)
    {
        if(tensorShape.rank() > 3) {
            std::cerr << "GL buffer source mode does not support batchsize larger than 1" << std::endl;
            std::exit(1);
        }
        else {
            batchSize = 1;
        }
    }
#endif
    std::cout << "Batch size for the container is " << batchSize << std::endl;

    // Open the input file listing and group input files into batches
    std::vector<std::vector<std::string>> inputs = preprocessInput(inputFile, batchSize);
    std::cerr << "11111111111111111111111111111111. " << std::endl;
    // Load contents of input file batches ino a SNPE tensor or user buffer,
    // execute the network with the input and save each of the returned output to a file.
    if(bufferType == USERBUFFER) {
        // SNPE allows its input and output buffers that are fed to the network
        // to come from user-backed buffers. First, SNPE buffers are created from
        // user-backed storage. These SNPE buffers are then supplied to the network
        // and the results are stored in user-backed output buffers. This allows for
        // reusing the same buffers for multiple inputs and outputs.
        zdl::DlSystem::UserBufferMap inputMap, outputMap;
        std::vector<std::unique_ptr<zdl::DlSystem::IUserBuffer>> snpeUserBackedInputBuffers, snpeUserBackedOutputBuffers;
        std::unordered_map<std::string, std::vector<uint8_t>> applicationOutputBuffers;
        createOutputBufferMap(outputMap, applicationOutputBuffers, snpeUserBackedOutputBuffers, snpe);
        std::cerr << "2222222222222222222222222. " << std::endl;
        if (userBufferSourceType == CPUBUFFER)
        {
            std::unordered_map<std::string, std::vector<uint8_t>> applicationInputBuffers;
            createInputBufferMap(inputMap, applicationInputBuffers, snpeUserBackedInputBuffers, snpe);

	    std::ifstream in(inputRAWFilePath, std::ifstream::binary);
            if (!in.is_open() || !in.good())
            {
      		std::cerr << "Failed to open input file: " << inputFile << "\n";
   	    }

   	    in.seekg(0, in.end);
   	    size_t length = in.tellg();
            in.seekg(0, in.beg);

	    std::cout<<"Length: "<<length<<std::endl;
            
            unsigned char* Ybuffer=new unsigned char[length];
            in.read(reinterpret_cast<char*>(Ybuffer), length);

	    unsigned char* Out_Ybuffer=new unsigned char[length];
            in.read(reinterpret_cast<char*>(Out_Ybuffer), length);
  
            //256x256
            if (width <=288 && height<=288) {
                // Load input user buffer(s) with values from file(s)
                if(batchSize > 1)
                    std::cout << "Batch is:" << batchSize << ":" << std::endl;
                size_t i=0;
		const auto& inputNamesOpt = snpe->getInputTensorNames();
	    	if (!inputNamesOpt) throw std::runtime_error("Error obtaining input tensor names");
	    	const zdl::DlSystem::StringList& inputNames = *inputNamesOpt;
	    	//assert(inputNames.size() > 0);

	    	if (inputNames.size()) std::cout << "Processing DNN Input: 288*288." << std::endl;

		if(true)
                {
		    std::cout << "width <=288 && height<=288." << std::endl;
		
		    for (size_t j = 0; j < inputNames.size(); j++) 
                    {
		    const char *name = inputNames.at(j);

		    // print out which crop Y image is being processed

		    // load file content onto application storage buffer,
		    // on top of which, SNPE has created a user buffer
		    loadByteDataFileBatched(Ybuffer,  width,  height, width, applicationInputBuffers.at(name), i);
		    }
	        }

                //loadInputUserBuffer(applicationInputBuffers, snpe, inputs[i]);
                //loadInputUserBuffer(applicationInputBuffers, snpe, Ybuffer, 256, 256);
                // Execute the input buffer map on the model with SNPE
                snpe->execute(inputMap, outputMap);
                // Save the execution results
                saveOutput(Ybuffer, width, height, width, outputMap, applicationOutputBuffers, OutputDir, i*batchSize, batchSize, 0);
            }
 
            //such as 500x500
            else 
            {
		std::cout << "width > 288 && height > 288." << std::endl;
                // Load input user buffer(s) with values from file(s)
                if(batchSize > 1)
                    std::cout << "Batch is:" << batchSize << ":" << std::endl;
                size_t i=0;
		const auto& inputNamesOpt = snpe->getInputTensorNames();
	    	if (!inputNamesOpt) throw std::runtime_error("Error obtaining input tensor names");
	    	const zdl::DlSystem::StringList& inputNames = *inputNamesOpt;
	    	//assert(inputNames.size() > 0);

	    	if (inputNames.size()) std::cout << "Processing DNN Input: 288*288." << std::endl;

		if(true)
                {
		    std::cout << "width > 288 && height > 288." << std::endl;
		
		    for (size_t j = 0; j < inputNames.size(); j++) 
                    {
		    const char *name = inputNames.at(j);
		    size_t i=0;
		    size_t width_crop_num = ceil((float)(width)/256);
		    size_t height_crop_num = ceil((float)(height)/256);
		    size_t crop_width_with_margin=0;
		    size_t crop_height_with_margin=0;
                    std::cout << "width_crop_num: " <<width_crop_num<<", height_crop_num: "<<height_crop_num<< std::endl;
		    unsigned char *crop_Ybuffer=Ybuffer;
		    unsigned char *margin_crop_Ybuffer=NULL;

		    unsigned char *Out_crop_Ybuffer=Out_Ybuffer;
		    unsigned char *Out_margin_crop_Ybuffer=NULL;
		    std::ostringstream path;
		    for(size_t m=0; m< height_crop_num; m++){
			for(size_t n=0; n< width_crop_num; n++){
                                 std::cout<<"m is : "<< m <<" , n is : "<< n <<std::endl;
         		         path << "/opt/SNPE/snpe-1.19.2/models/srn/out-data" << "/"
              			   << m << "_" << n << ".raw";
				   std::ofstream outos(path.str(), std::ofstream::binary);
				   if (!outos)
				   {
				      std::cerr << "Failed to open output file for writing: " << path.str() << "\n";
				      std::exit(EXIT_FAILURE);
				   }
	            		// print out which crop Y image is being processed

	            		// load file content onto application storage buffer,
	            		// on top of which, SNPE has created a user buffer
					if(true)  //old: m< height_crop_num-1 && n<width_crop_num-1
  	            		        { 
						crop_Ybuffer = Ybuffer+m*1024*width+n*1024;
						Out_crop_Ybuffer = Out_Ybuffer+m*1024*width+n*1024;
                 				if(m==0 && n==0)
                                                {
					            margin_crop_Ybuffer = crop_Ybuffer;
						    Out_margin_crop_Ybuffer = Out_crop_Ybuffer;
						    if((n+1)*256+margin_reserve > width)
							crop_width_with_margin = width-n*256;
						    else
							crop_width_with_margin = 256+margin_reserve;
						    if((m+1)*256+margin_reserve > height)
							crop_height_with_margin = height-m*256;
						    else
						        crop_height_with_margin = 256+margin_reserve;
						    loadByteDataFileBatched(margin_crop_Ybuffer, crop_width_with_margin, crop_height_with_margin, width, applicationInputBuffers.at(name), i);
						    snpe->execute(inputMap, outputMap);
                                                    std::cout<<"snpe->execute. "<<std::endl;
                				    // Save the execution results
                                                    std::cout<<"Going to saveOutput..."<<std::endl;
                				    saveOutput(Out_margin_crop_Ybuffer, crop_width_with_margin, crop_height_with_margin, width, outputMap, applicationOutputBuffers, OutputDir, i*batchSize, batchSize, 0);
						    if(!outos.write(reinterpret_cast<char*>(Out_Ybuffer), length))
						    {
						      std::cerr << "Failed to write data to: " << path.str() << "\n";
						      std::exit(EXIT_FAILURE);
						    }

						}
                                                else if(m==0 && n!=0)
						{
					            margin_crop_Ybuffer = crop_Ybuffer-64;
						    Out_margin_crop_Ybuffer = Out_crop_Ybuffer-64;
						    if((n+1)*256+margin_reserve > width)
							crop_width_with_margin = width-n*256+margin_reserve;
						    else
							crop_width_with_margin = 256+margin_reserve*2;
						    if((m+1)*256+margin_reserve > height)
							crop_height_with_margin = height-m*256;
						    else
						        crop_height_with_margin = 256+margin_reserve;
						    loadByteDataFileBatched(margin_crop_Ybuffer, crop_width_with_margin, crop_height_with_margin, width, applicationInputBuffers.at(name), i);
						    snpe->execute(inputMap, outputMap);
                                                    std::cout<<"snpe->execute. "<<std::endl;
                				    // Save the execution results
                                                    std::cout<<"Going to saveOutput..."<<std::endl;
                				    saveOutput(Out_margin_crop_Ybuffer, crop_width_with_margin, crop_height_with_margin, width, outputMap, applicationOutputBuffers, OutputDir, i*batchSize, batchSize, 1);
						    if(!outos.write(reinterpret_cast<char*>(Out_Ybuffer), length))
						    {
						      std::cerr << "Failed to write data to: " << path.str() << "\n";
						      std::exit(EXIT_FAILURE);
						    }
						}
                                                else if(m!=0 && n==0)
						{
					            margin_crop_Ybuffer = crop_Ybuffer-64*width;
						    Out_margin_crop_Ybuffer = Out_crop_Ybuffer-64*width;
						    if((n+1)*256+margin_reserve > width)
							crop_width_with_margin = width-n*256;
						    else
							crop_width_with_margin = 256+margin_reserve;
						    if((m+1)*256+margin_reserve > height)
							crop_height_with_margin = height-m*256+margin_reserve;
						    else
						        crop_height_with_margin = 256+margin_reserve*2;
						    loadByteDataFileBatched(margin_crop_Ybuffer, crop_width_with_margin, crop_height_with_margin, width, applicationInputBuffers.at(name), i);
						    snpe->execute(inputMap, outputMap);
                                                    std::cout<<"snpe->execute. "<<std::endl;
                				    // Save the execution results
                                                    std::cout<<"Going to saveOutput..."<<std::endl;
                				    saveOutput(Out_margin_crop_Ybuffer, crop_width_with_margin, crop_height_with_margin, width, outputMap, applicationOutputBuffers, OutputDir, i*batchSize, batchSize, 2);
						    if(!outos.write(reinterpret_cast<char*>(Out_Ybuffer), length))
						    {
						      std::cerr << "Failed to write data to: " << path.str() << "\n";
						      std::exit(EXIT_FAILURE);
						    }
						}
						else						    
						{
					            margin_crop_Ybuffer = crop_Ybuffer-64*width-64;
						    Out_margin_crop_Ybuffer = Out_crop_Ybuffer-64*width-64;
						    if((n+1)*256+margin_reserve > width)
							crop_width_with_margin = width-n*256+margin_reserve;
						    else
							crop_width_with_margin = 256+margin_reserve*2;
						    if((m+1)*256+margin_reserve > height)
							crop_height_with_margin = height-m*256+margin_reserve;
						    else
						        crop_height_with_margin = 256+margin_reserve*2;
						    loadByteDataFileBatched(margin_crop_Ybuffer, crop_width_with_margin, crop_height_with_margin, width, applicationInputBuffers.at(name), i);
						    snpe->execute(inputMap, outputMap);
                                                    std::cout<<"snpe->execute. "<<std::endl;
                				    // Save the execution results
                                                    std::cout<<"Going to saveOutput..."<<std::endl;
                				    saveOutput(Out_margin_crop_Ybuffer, crop_width_with_margin, crop_height_with_margin, width, outputMap, applicationOutputBuffers, OutputDir, i*batchSize, batchSize, 3);
						    if(!outos.write(reinterpret_cast<char*>(Out_Ybuffer), length))
						    {
						      std::cerr << "Failed to write data to: " << path.str() << "\n";
						      std::exit(EXIT_FAILURE);
						    }
						}
						
					}
	     	              
			  }//end n
		    }//end m
		    
		    }//end name
	        }//if
           }//end run

           const std::string save_path="/opt/SNPE/snpe-1.19.2/models/srn/data/cropped_700x700/srn_out_plastic_cup_700x700.raw";
           std::ofstream os(save_path, std::ofstream::binary);
	   if (!os)
	   {
	      std::cerr << "Failed to open output file for writing: " << save_path << "\n";
	      std::exit(EXIT_FAILURE);
	   }

	   if(!os.write(reinterpret_cast<char*>(Out_Ybuffer), length))
	   {
	      std::cerr << "Failed to write data to: " << save_path << "\n";
	      std::exit(EXIT_FAILURE);
	   }
	  
           delete[] Ybuffer;
	   delete[] Out_Ybuffer;
        }
#ifdef ANDROID
        if(userBufferSourceType  == GLBUFFER)
        {
            std::unordered_map<std::string, GLuint> applicationInputBuffers;
            createInputBufferMap(inputMap, applicationInputBuffers, snpeUserBackedInputBuffers, snpe);
            GLuint glBuffers = 0;
            for(size_t i = 0; i < inputs.size(); i++) {
                glBuffers = glBuffer->convertImage2GLBuffer(inputs[i]);
                loadInputUserBuffer(applicationInputBuffers, snpe, glBuffers);
                snpe->execute(inputMap, outputMap);
                saveOutput(outputMap, applicationOutputBuffers, OutputDir, i*batchSize, batchSize);
                glDeleteBuffers(1, &glBuffers);
            }
        }
#endif
    } else if(bufferType == ITENSOR) {

        // A tensor map for SNPE execution outputs
        zdl::DlSystem::TensorMap outputTensorMap;

        for (size_t i = 0; i < inputs.size(); i++) {
            // Load input/output buffers with ITensor
            if(batchSize > 1)
                std::cout << "Batch " << i << ":" << std::endl;
            std::unique_ptr<zdl::DlSystem::ITensor> inputTensor = loadInputTensor(snpe, inputs[i]);
            // Execute the input tensor on the model with SNPE
            snpe->execute(inputTensor.get(), outputTensorMap);
            // Save the execution results
            saveOutput(outputTensorMap,OutputDir,i*batchSize, batchSize);
        }
    }
    
    return 0;
}
