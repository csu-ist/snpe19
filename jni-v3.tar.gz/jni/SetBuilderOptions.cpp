//==============================================================================
//
//  Copyright (c) 2017 Qualcomm Technologies, Inc.
//  All Rights Reserved.
//  Confidential and Proprietary - Qualcomm Technologies, Inc.
//
//==============================================================================

#include "SetBuilderOptions.hpp"

#include "SNPE/SNPE.hpp"
#include "DlContainer/IDlContainer.hpp"
#include "SNPE/SNPEBuilder.hpp"

std::unique_ptr<zdl::SNPE::SNPE> setBuilderOptions(std::unique_ptr<zdl::DlContainer::IDlContainer> & container,
                                                   zdl::DlSystem::Runtime_t runtime,
                                                   zdl::DlSystem::UDLBundle udlBundle,
                                                   bool useUserSuppliedBuffers,
                                                   zdl::DlSystem::PlatformConfig platformConfig)
{
    zdl::DlSystem::TensorShapeMap tsm;
    //std::vector<size_t> new_size = {1, 256, 256, 1}; 
    //zdl::DlSystem::TensorShape input_tensorShape(new_size);
    tsm.add("inputdata", {1, 288, 288, 1});
   
    std::unique_ptr<zdl::SNPE::SNPE> snpe;
    zdl::SNPE::SNPEBuilder snpeBuilder(container.get());
    snpe = snpeBuilder.setOutputLayers({})
       .setRuntimeProcessor(runtime)
       .setUdlBundle(udlBundle)
       .setUseUserSuppliedBuffers(useUserSuppliedBuffers)
       .setPlatformConfig(platformConfig)
       .build();
 
    //zdl::DlSystem::TensorShapeMap tsm ;  //= TensorShapeMap();
	
    //const auto& inputNamesOpt = snpe->getInputTensorNames();
    //const zdl::DlSystem::StringList& inputNames = *inputNamesOpt;
    //const char * inputname_0 = inputNames.at(0);
    
    //std::vector<size_t> new_size = {1, 288, 288, 1}; 
    //zdl::DlSystem::TensorShape input_tensorShape(new_size);

    //tsm.add(inputname_0, input_tensorShape);

    //snpe = snpeBuilder.setInputDimensions(tsm).build();
    return snpe;
}
