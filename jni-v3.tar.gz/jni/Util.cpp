//==============================================================================
//
//  Copyright (c) 2017-2018 Qualcomm Technologies, Inc.
//  All Rights Reserved.
//  Confidential and Proprietary - Qualcomm Technologies, Inc.
//
//==============================================================================

#include <fstream>
#include <iostream>
#include <vector>
#include <sstream>
#include <cstring>
#include <string>
#include <cstdlib>
#include <sys/stat.h>
#include <cerrno>

#include "Util.hpp"

#include "DlSystem/ITensorFactory.hpp"
#include "DlSystem/TensorShape.hpp"

size_t calcSizeFromDims(const zdl::DlSystem::Dimension *dims, size_t rank, size_t elementSize)
{
   if (rank == 0) return 0;
   size_t size = elementSize;
   while (rank--) size *= *dims++;
   return size;
}


bool EnsureDirectory(const std::string& dir)
{
   auto i = dir.find_last_of('/');
   std::string prefix = dir.substr(0, i);

   if (dir.empty() || dir == "." || dir == "..")
   {
      return true;
   }

   if (i != std::string::npos && !EnsureDirectory(prefix))
   {
      return false;
   }

   int rc = mkdir(dir.c_str(),  S_IRWXU | S_IRGRP | S_IXGRP | S_IROTH | S_IXOTH);
   if (rc == -1 && errno != EEXIST)
   {
      return false;
   }
   else
   {
      struct stat st;
      if (stat(dir.c_str(), &st) == -1)
      {
         return false;
      }

      return S_ISDIR(st.st_mode);
   }
}

std::vector<float> loadFloatDataFile(const std::string& inputFile)
{
    std::vector<float> vec;
    loadByteDataFile(inputFile, vec);
    return vec;
}

std::vector<unsigned char> loadByteDataFile(const std::string& inputFile)
{
   std::vector<unsigned char> vec;
   loadByteDataFile(inputFile, vec);
   return vec;
}

template<typename T>
void loadByteDataFile(const std::string& inputFile, std::vector<T>& loadVector)
{
   std::ifstream in(inputFile, std::ifstream::binary);
   if (!in.is_open() || !in.good())
   {
      std::cerr << "Failed to open input file: " << inputFile << "\n";
   }

   in.seekg(0, in.end);
   size_t length = in.tellg();
   in.seekg(0, in.beg);

   if (loadVector.size() == 0) {
      loadVector.resize(length / sizeof(T));
   } else if (loadVector.size() < length) {
      std::cerr << "Vector is not large enough to hold data of input file: " << inputFile << "\n";
   }

   if (!in.read(reinterpret_cast<char*>(&loadVector[0]), length))
   {
      std::cerr << "Failed to read the contents of: " << inputFile << "\n";
   }
}

std::vector<unsigned char> loadByteDataFileBatched(const std::string& inputFile)
{
   std::vector<unsigned char> vec;
   size_t offset=0;
   loadByteDataFileBatched(inputFile, vec, offset);
   return vec;
}

template<typename T>
void loadByteDataFileBatched(const std::string& inputFile, std::vector<T>& loadVector, size_t offset)
{
    std::cerr<<"Offset: "<< offset <<"\n";
    std::cerr<<"At start ! loadVecto-v0.size(): "<< loadVector.size()<<"\n";
    std::ifstream in(inputFile, std::ifstream::binary);
    if (!in.is_open() || !in.good())
    {
        std::cerr << "Failed to open input file: " << inputFile << "\n";
    }

    in.seekg(0, in.end);
    size_t length = in.tellg();
    in.seekg(0, in.beg);

    if (loadVector.size() == 0) {
        loadVector.resize(length / sizeof(T));
    } else if (loadVector.size() < length) {
        std::cerr << "Vector is not large enough to hold data of input file: " << inputFile << "\n";
    }

    loadVector.resize( (offset+1) * length / sizeof(T) );
    std::cerr << "loadVector.resize( (offset+1) * length / sizeof(T) ); "<< "\n";
    std::cerr<<"Atfer resize~ loadVecto-v1.size(): "<< loadVector.size()<<"\n";

    if (!in.read( reinterpret_cast<char*> (&loadVector[offset * length/ sizeof(T) ]), length) )
    {
        std::cerr << "Failed to read the contents of: " << inputFile << "\n";
    }

    std::cerr<<"loadVecto-v0.size(): "<< loadVector.size()<<"\n";

    std::ofstream outputTXT("/opt/SNPE/snpe-1.19.2/ybuffer-v0.txt");
        for(size_t i=0; i<=loadVector.size(); i++)
            outputTXT << (unsigned short)(loadVector[i])<<", ";	
        outputTXT.close();
}


void loadByteDataFileBatched(unsigned char *Ybuffer, size_t crop_width, size_t crop_height, size_t full_width, std::vector<uint8_t>& loadVector, size_t offset)
{
        std::cerr<<"Offset: "<< offset <<"\n";
        if(offset==0)
            loadVector.resize(0);
        std::cerr<<"At start ! loadVecto-v1.size(): "<< loadVector.size()<<"\n";
	size_t length = 288*288*4;

	/*if (loadVector.size() == 0) {
		loadVector.resize(length / sizeof(T));
	} else if (loadVector.size() < length) {
		std::cerr << "Vector is not large enough to hold data of input file: " << "\n";
	}

	loadVector.resize( (offset+1) * length / sizeof(T) );*/

	unsigned char *beginbuffer= Ybuffer;
	//unsigned char beginbuffer_value = *beginbuffer;
	std::vector<uint8_t>::iterator it = loadVector.end();
	size_t pre_loadVectorSize=loadVector.size();
        

	for(size_t line=0;  line<crop_height;  line++)
	{
		loadVector.insert(it, beginbuffer, beginbuffer+crop_width*4);
		if(crop_width<288)
			loadVector.resize(loadVector.size()+1152-crop_width*4);
		it = loadVector.end();
		beginbuffer =  beginbuffer+full_width*4;
		//beginbuffer_value = *beginbuffer;
	}


        std::cerr<<"Atfer copy~ loadVecto-v1.size(): "<< loadVector.size()<<"\n";
	if(loadVector.size()>pre_loadVectorSize && loadVector.size()!=pre_loadVectorSize+length)
		loadVector.resize(pre_loadVectorSize+length);

        std::cerr<<"At end. loadVecto-v1.size(): "<< loadVector.size()<<"\n";

        //std::ofstream outputTXT("/opt/SNPE/snpe-1.19.2/ybuffer.txt");
        //for(size_t i=0; i<=loadVector.size(); i++)
            //outputTXT << (unsigned short)(loadVector[i])<<", ";	
        //outputTXT.close();
}



void SaveITensorBatched(const std::string& path, const zdl::DlSystem::ITensor* tensor, size_t batchIndex, size_t batchChunk)
{
   if(batchChunk == 0)
      batchChunk = tensor->getSize();
   // Create the directory path if it does not exist
   auto idx = path.find_last_of('/');
   if (idx != std::string::npos)
   {
      std::string dir = path.substr(0, idx);
      if (!EnsureDirectory(dir))
      {
         std::cerr << "Failed to create output directory: " << dir << ": "
                   << std::strerror(errno) << "\n";
         std::exit(EXIT_FAILURE);
      }
   }

   std::ofstream os(path, std::ofstream::binary);
   if (!os)
   {
      std::cerr << "Failed to open output file for writing: " << path << "\n";
      std::exit(EXIT_FAILURE);
   }

   for ( auto it = tensor->cbegin() + batchIndex * batchChunk; it != tensor->cbegin() + (batchIndex+1) * batchChunk; ++it )
   {
      float f = *it;
      if (!os.write(reinterpret_cast<char*>(&f), sizeof(float)))
      {
         std::cerr << "Failed to write data to: " << path << "\n";
         std::exit(EXIT_FAILURE);
      }
   }
}

void SaveUserBufferBatched(const std::string& path, const std::vector<uint8_t>& buffer, size_t batchIndex, size_t batchChunk)
{
   if(batchChunk == 0)
      batchChunk = buffer.size();
   // Create the directory path if it does not exist
   auto idx = path.find_last_of('/');
   if (idx != std::string::npos)
   {
      std::string dir = path.substr(0, idx);
      if (!EnsureDirectory(dir))
      {
         std::cerr << "Failed to create output directory: " << dir << ": "
                   << std::strerror(errno) << "\n";
         std::exit(EXIT_FAILURE);
      }
   }

   std::ofstream os(path, std::ofstream::binary);
   if (!os)
   {
      std::cerr << "Failed to open output file for writing: " << path << "\n";
      std::exit(EXIT_FAILURE);
   }

   for ( auto it = buffer.begin() + batchIndex * batchChunk; it != buffer.begin() + (batchIndex+1) * batchChunk; ++it )
   {
      uint8_t u = *it;
      if(!os.write((char*)(&u), sizeof(uint8_t)))
      {
        std::cerr << "Failed to write data to: " << path << "\n";
        std::exit(EXIT_FAILURE);
      }
   }
}

void SaveUserBufferBatched(unsigned char *Ybuffer, size_t crop_width, size_t crop_height, size_t full_width,
		const std::string& path, const std::vector<uint8_t>& buffer, size_t batchIndex, size_t batchChunk, uint8_t location_flag)
{
   if(batchChunk == 0)
      batchChunk = buffer.size();
   // Create the directory path if it does not exist
  
  std::cerr << "crop_width is " << crop_width << "\n";
  std::cerr << "crop_height is " << crop_height << "\n";
  std::cerr << "full_width is " << full_width << "\n";

  std::cerr << "Begin to recover crop_Ybuffer. buffer.size() is " << buffer.size() << "\n";
  if(location_flag==0)
  {
	  std::cerr << "location_flag is " << location_flag << "\n";
	  unsigned char *beginbuffer= Ybuffer;
	  size_t crop_width_4 = crop_width*4;
	  size_t buffer_vaild_size = 288*crop_height*4;
	  std::cerr << "buffer_vaild_size is " << buffer_vaild_size << "\n";
	  if(crop_width==288)  //size of crop_img equal 288x288 
	  {
		  for(size_t it=0; it<buffer_vaild_size; )
		  {
		    if(it>0 && (it%1152)==0)
		    {   
			beginbuffer += (full_width-crop_width)*4;
		    }  
		    *beginbuffer = buffer[it];
		    
		    beginbuffer++;
		    it++;
		  }
	  }
	  
	  else   //size of crop_img less than 288x288 
	  {
		  for(size_t it=0; it<buffer_vaild_size; )
		  {
		    if(it>0 && (it%1152)==crop_width_4)
		    {   
			//std::cerr<<"current it:"<<it<<"\n";
			beginbuffer += (full_width-crop_width)*4;
			//std::cerr << "beginbuffer + " << (full_width-crop_width)*4 << "\n";
			it += (288-crop_width)*4;
		    }  
		    *beginbuffer = buffer[it];
		    
		    beginbuffer++;
		    it++;
		  }
	  }
	  std::cerr << "Ybuffer is recover." << "\n";
  }

  if(location_flag==1)  //m==0 && n!=0
  {
	  std::cerr << "location_flag is " << location_flag << "\n";
	  unsigned char *beginbuffer= Ybuffer;
	  size_t crop_width_4 = crop_width*4;
	  size_t buffer_vaild_size = 288*crop_height*4;
	  std::cerr << "buffer_vaild_size is " << buffer_vaild_size << "\n";
	  if(crop_width==288)  //size of crop_img equal 288x288 
	  {
		  for(size_t it=0; it<buffer_vaild_size; )
		  {
		    if(it>0 && (it%1152)==0)
		    {   
			beginbuffer += (full_width-crop_width)*4;
		    }  
                    if((it%1152)<16*4 )  // || (it%1152)>271*4 || (it%1152)>271*4
			;  //do nothing
		    else
		        *beginbuffer = buffer[it];
		    
		    beginbuffer++;
		    it++;
		  }
	  }
	  
	  else   //size of crop_img less than 288x288 
	  {
		  for(size_t it=0; it<buffer_vaild_size; )
		  {
		    if(it>0 && (it%1152)==crop_width_4)
		    {   
			//std::cerr<<"current it:"<<it<<"\n";
			beginbuffer += (full_width-crop_width)*4;
			//std::cerr << "beginbuffer + " << (full_width-crop_width)*4 << "\n";
			it += (288-crop_width)*4;
		    }  
		    if((it%1152)<16*4)  // || int(it/1152)>255|| (it%1152)>(crop_width_4-64) 
			;  //do nothing
		    else
		        *beginbuffer = buffer[it];
		    
		    beginbuffer++;
		    it++;
		  }
	  }
	  std::cerr << "Ybuffer is recover." << "\n";
  }

  if(location_flag==2)  //m!=0 && n==0
  {
	  std::cerr << "location_flag is " << location_flag << "\n";
	  unsigned char *beginbuffer= Ybuffer;
	  size_t crop_width_4 = crop_width*4;
	  size_t buffer_vaild_size = 288*crop_height*4;
	  std::cerr << "buffer_vaild_size is " << buffer_vaild_size << "\n";
	  if(crop_width==288)  //size of crop_img equal 288x288 
	  {
		  for(size_t it=0; it<buffer_vaild_size; )
		  {
		    if(it>0 && (it%1152)==0)
		    {   
			beginbuffer += (full_width-crop_width)*4;
		    }  
                    if(int(it/1152)<16 )  //(it%1152)>255*4 ||  || int(it/1152)>271
			;  //do nothing
		    else
		        *beginbuffer = buffer[it];
		    
		    beginbuffer++;
		    it++;
		  }
	  }
	  
	  else   //size of crop_img less than 288x288 
	  {
		  for(size_t it=0; it<buffer_vaild_size; )
		  {
		    if(it>0 && (it%1152)==crop_width_4)
		    {   
			//std::cerr<<"current it:"<<it<<"\n";
			beginbuffer += (full_width-crop_width)*4;
			//std::cerr << "beginbuffer + " << (full_width-crop_width)*4 << "\n";
			it += (288-crop_width)*4;
		    }  
		    if(int(it/1152)<16)  // (it%1152)>(crop_width_4-64) || || int(it/1152)>271
			;  //do nothing
		    else
		        *beginbuffer = buffer[it];
		    
		    beginbuffer++;
		    it++;
		  }
	  }
	  std::cerr << "Ybuffer is recover." << "\n";
  }

  if(location_flag==3)  //m!=0 && n!=0
  {
	  std::cerr << "location_flag is " << location_flag << "\n";
	  unsigned char *beginbuffer= Ybuffer;
	  size_t crop_width_4 = crop_width*4;
	  size_t buffer_vaild_size = 288*crop_height*4;
	  std::cerr << "buffer_vaild_size is " << buffer_vaild_size << "\n";
	  if(crop_width==288)  //size of crop_img equal 288x288 
	  {
		  for(size_t it=0; it<buffer_vaild_size; )
		  {
		    if(it>0 && (it%1152)==0)
		    {   
			beginbuffer += (full_width-crop_width)*4;
		    }  
                    if(int(it/1152)<16 || int(it/1152)>271 || (it%1152)<16*4 )   //|| (it%1152)>271*4
			;  //do nothing
		    else
		        *beginbuffer = buffer[it];
		    
		    beginbuffer++;
		    it++;
		  }
	  }
	  
	  else   //size of crop_img less than 288x288 
	  {
		  for(size_t it=0; it<buffer_vaild_size; )
		  {
		    if(it>0 && (it%1152)==crop_width_4)
		    {   
			//std::cerr<<"current it:"<<it<<"\n";
			beginbuffer += (full_width-crop_width)*4;
			//std::cerr << "beginbuffer + " << (full_width-crop_width)*4 << "\n";
			it += (288-crop_width)*4;
		    }  
		    if(int(it/1152)<16 || int(it/1152)>271 || (it%1152)<16*4 ) //|| (it%1152)>(crop_width_4-64))
			;  //do nothing
		    else
		        *beginbuffer = buffer[it];
		    
		    beginbuffer++;
		    it++;
		  }
	  }
	  std::cerr << "Ybuffer is recover." << "\n";
   }

}
